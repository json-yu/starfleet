var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'jyujson',
applicationName: 'starfleet-apollo-lambda',
appUid: '29zbF9qYTRtpg9tDb2',
tenantUid: '7StLQkMwlXRFkXRxsK',
deploymentUid: '224b2d2f-baf2-49bf-8bfd-af4735c80db9',
serviceName: 'apollo-lambda-test',
stageName: 'dev',
pluginVersion: '3.2.5'})
const handlerWrapperArgs = { functionName: 'apollo-lambda-test-dev-GraphQLPost', timeout: 6}
try {
  const userHandler = require('./graphql.js')
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
